			<div class="footer">
            	<p>Copyright &copy; 2016. Todos os Direitos Reservados JrNext. JrNext: <a href="http://jrnext.com.br" target="_blank">JrNext</a></p>
            </div><!--footer-->
            
        </div><!--maincontent-->
        
     	</div><!--mainwrapperinner-->
    </div><!--mainwrapper-->
	<!-- END OF MAIN CONTENT -->
    

</body>
</html>
