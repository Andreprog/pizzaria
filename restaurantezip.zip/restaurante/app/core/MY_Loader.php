<?php
(defined('BASEPATH')) or exit('Acesso direto n&atilde;o permitido');

/* load the HMVC_Loader class */
require APPPATH . 'third_party/HMVC/Loader.php';

class MY_Loader extends HMVC_Loader {
}