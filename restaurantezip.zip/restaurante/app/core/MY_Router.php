<?php
(defined('BASEPATH')) or exit('Acesso direto n&atilde;o permitido');

/* load the HMVC_Router class */
require APPPATH . 'third_party/HMVC/Router.php';

class MY_Router extends HMVC_Router {
}