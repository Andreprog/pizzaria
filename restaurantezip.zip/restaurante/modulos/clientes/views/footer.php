			<div class="footer" style="text-align:center">
            	<p>Copyright &copy; 2016. JrNext Todos os Direitos Reservados.</p>
            </div><!--footer-->
            
        </div><!--maincontent-->
        
     	</div><!--mainwrapperinner-->
    </div><!--mainwrapper-->
	<!-- END OF MAIN CONTENT -->
    

</body>
</html>
