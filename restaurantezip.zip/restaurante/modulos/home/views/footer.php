			<div class="footer" style="text-align:center">
            	<p>Copyright &copy; 2016. www.jrnext.com.br.</p>
            </div><!--footer-->
            
        </div><!--maincontent-->
        
     	</div><!--mainwrapperinner-->
    </div><!--mainwrapper-->
	<!-- END OF MAIN CONTENT -->
    

</body>
</html>
